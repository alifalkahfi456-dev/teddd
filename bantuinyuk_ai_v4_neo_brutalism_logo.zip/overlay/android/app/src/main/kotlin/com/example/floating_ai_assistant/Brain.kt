package com.example.floating_ai_assistant

import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import io.flutter.FlutterInjector
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.embedding.engine.dart.DartExecutor
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import java.util.concurrent.atomic.AtomicInteger

/**
 * Jembatan ke "otak" Dart (lib/brain): FlutterEngine headless yang hidup selama proses hidup,
 * jadi overlay tetap bisa bertanya ke Gemini walau Activity ditutup. Satu engine = satu salinan state.
 *
 * Kotlin → Dart : ask, cancel, prepare, getSettings, saveBackend, setHistoryOn, setAccepted, syncNow,
 *                 getHistory, setFav, clearHistory
 * Dart → Kotlin : ready, getBubble, setBubble (pengaturan bubble tinggal di SharedPreferences native)
 *
 * Semua dipanggil dari main thread. FlutterEngine(context) mendaftarkan plugin (shared_preferences) otomatis.
 */
object Brain {
    class Err(msg: String) : Exception(msg)

    private const val CH = "floating_brain"
    private const val READY_TIMEOUT_MS = 15_000L

    private class Pending(
        val method: String,
        val args: Any?,
        val cb: (Result<Any?>) -> Unit,
        val cancelled: () -> Boolean
    ) { var done = false }

    private val main = Handler(Looper.getMainLooper())
    private val ids = AtomicInteger(0)
    private val queue = ArrayList<Pending>()
    private var engine: FlutterEngine? = null
    private var channel: MethodChannel? = null
    private var ready = false
    private var app: Context? = null

    fun nextId(): Int = ids.incrementAndGet()

    private fun onMain(block: () -> Unit) {
        if (Looper.myLooper() == Looper.getMainLooper()) block() else main.post(block)
    }

    private fun ensure(ctx: Context) {
        if (engine != null) return
        val a = ctx.applicationContext
        app = a
        val e = FlutterEngine(a)
        val ch = MethodChannel(e.dartExecutor.binaryMessenger, CH)
        ch.setMethodCallHandler { call, res -> onHost(call, res) }
        engine = e; channel = ch
        e.dartExecutor.executeDartEntrypoint(
            DartExecutor.DartEntrypoint(FlutterInjector.instance().flutterLoader().findAppBundlePath(), "brainMain")
        )
    }

    /** Nyalakan engine lebih awal supaya panggilan pertama tidak menunggu. */
    fun warm(ctx: Context) = onMain { ensure(ctx) }

    fun call(ctx: Context, method: String, args: Any?, cancelled: () -> Boolean = { false }, cb: (Result<Any?>) -> Unit) {
        onMain {
            ensure(ctx)
            val p = Pending(method, args, cb, cancelled)
            if (ready) send(p) else {
                queue.add(p)
                main.postDelayed({
                    if (!p.done && queue.remove(p)) { p.done = true; cb(Result.failure(Err("Mesin AI belum siap. Coba lagi."))) }
                }, READY_TIMEOUT_MS)
            }
        }
    }

    fun cancel(id: Int) = onMain { if (ready) channel?.invokeMethod("cancel", mapOf("id" to id)) }

    private fun send(p: Pending) {
        if (p.cancelled()) { p.done = true; return }
        channel!!.invokeMethod(p.method, p.args, object : MethodChannel.Result {
            override fun success(result: Any?) { if (!p.done) { p.done = true; p.cb(Result.success(result)) } }
            override fun error(errorCode: String, errorMessage: String?, errorDetails: Any?) {
                if (!p.done) { p.done = true; p.cb(Result.failure(Err(errorMessage ?: "Gagal"))) }
            }
            override fun notImplemented() {
                if (!p.done) { p.done = true; p.cb(Result.failure(Err("Fitur belum didukung otak AI."))) }
            }
        })
    }

    // ---- panggilan dari Dart
    private fun onHost(call: MethodCall, res: MethodChannel.Result) {
        val a = app ?: return res.error("NO_CONTEXT", "Konteks belum siap", null)
        when (call.method) {
            "ready" -> {
                ready = true
                val q = ArrayList(queue); queue.clear()
                q.forEach { send(it) }
                res.success(null)
            }
            "getBubble" -> {
                val p = Store.p(a)
                res.success(mapOf(
                    "size" to p.getInt("size", 64),
                    "alpha" to p.getFloat("alpha", 0.85f).toDouble(),
                    "color" to p.getInt("color", 0xFF3B82F6.toInt()),
                    "shape" to p.getInt("shape", 0),
                    "ts" to p.getLong("settings_ts", 0L)
                ))
            }
            "setBubble" -> {
                val e = Store.p(a).edit()
                call.argument<Number>("size")?.let { e.putInt("size", it.toInt()) }
                call.argument<Number>("alpha")?.let { e.putFloat("alpha", it.toFloat()) }
                call.argument<Number>("color")?.let { e.putInt("color", it.toInt()) }
                call.argument<Number>("shape")?.let { e.putInt("shape", it.toInt()) }
                call.argument<Number>("ts")?.let { e.putLong("settings_ts", it.toLong()) }
                e.apply()
                // Layanan yang sedang jalan memuat ulang gaya bubble dari prefs.
                if (FloatingOverlayService.running) a.startService(Intent(a, FloatingOverlayService::class.java))
                res.success(null)
            }
            else -> res.notImplemented()
        }
    }
}
