package com.example.floating_ai_assistant

import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.WindowManager

/** Satu sesi MediaProjection + satu VirtualDisplay (Android 14 melarang lebih dari satu). */
class ScreenCaptureManager(private val svc: Service, private val onStopped: () -> Unit) {
    private var proj: MediaProjection? = null
    private var reader: ImageReader? = null
    private var vd: VirtualDisplay? = null
    private var sw = 0
    private var sh = 0
    private var last: Bitmap? = null
    private val handler = Handler(Looper.getMainLooper())
    val active: Boolean get() = proj != null

    companion object {
        /** Layar hitam total biasanya berarti aplikasi target memakai FLAG_SECURE. */
        fun isBlank(b: Bitmap): Boolean {
            // Pindai area tengah (tanpa status/navigation bar, yang tetap tampil walau jendela FLAG_SECURE dihitamkan).
            // Grid jarang bisa salah menganggap layar tema gelap AMOLED sebagai "diblokir".
            val row = IntArray(b.width)
            for (y in b.height / 10 until b.height * 9 / 10) {
                b.getPixels(row, 0, b.width, 0, y, b.width, 1)
                for (px in row) if ((px and 0xFFFFFF) != 0) return false
            }
            return true
        }
    }

    private fun size(): android.graphics.Point =
        realSize(svc.getSystemService(Context.WINDOW_SERVICE) as WindowManager)

    fun start(code: Int, data: Intent) {
        release()
        val mpm = svc.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val p = mpm.getMediaProjection(code, data)
        val dm = svc.resources.displayMetrics
        val s = size(); sw = s.x; sh = s.y
        p.registerCallback(object : MediaProjection.Callback() {
            // Hanya bereaksi bila proyeksi ini masih yang aktif; release() manual sudah mengosongkan `proj`,
            // jadi callback lama tidak bisa mematikan sesi baru.
            override fun onStop() { handler.post { if (proj === p) { release(); onStopped() } } }
        }, handler)
        val r = ImageReader.newInstance(sw, sh, PixelFormat.RGBA_8888, 2)
        vd = p.createVirtualDisplay("fai-capture", sw, sh, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, handler)
        proj = p; reader = r
    }

    /** Dipanggil saat rotasi / perubahan ukuran layar. */
    fun onResize() {
        val v = vd ?: return
        val s = size()
        if (s.x == sw && s.y == sh) return
        sw = s.x; sh = s.y
        reader?.close()
        val r = ImageReader.newInstance(sw, sh, PixelFormat.RGBA_8888, 2)
        v.resize(sw, sh, svc.resources.displayMetrics.densityDpi)
        v.surface = r.surface
        reader = r
    }

    fun capture(cb: (Bitmap?) -> Unit) {
        val r = reader ?: return cb(null)
        Thread {
            var bmp: Bitmap? = null
            val end = SystemClock.uptimeMillis() + 700
            while (bmp == null && SystemClock.uptimeMillis() < end) {
                val img = runCatching { r.acquireLatestImage() }.getOrNull()
                if (img != null) { bmp = toBitmap(img); img.close() } else Thread.sleep(40)
            }
            if (bmp != null) last = bmp
            val out = bmp ?: last
            handler.post { cb(out) }
        }.start()
    }

    private fun toBitmap(img: Image): Bitmap {
        val pl = img.planes[0]
        val rowPad = pl.rowStride - pl.pixelStride * img.width
        val full = Bitmap.createBitmap(img.width + rowPad / pl.pixelStride, img.height, Bitmap.Config.ARGB_8888)
        full.copyPixelsFromBuffer(pl.buffer)
        if (rowPad == 0) return full
        val out = Bitmap.createBitmap(full, 0, 0, img.width, img.height)
        full.recycle()
        return out
    }

    fun release() {
        val p = proj
        proj = null
        runCatching { vd?.release() }; vd = null
        runCatching { reader?.close() }; reader = null
        last = null
        runCatching { p?.stop() }
    }
}
