package com.example.floating_ai_assistant

object CropMath {
    /** Peta kotak seleksi (koordinat view) ke koordinat bitmap asli: [l, t, r, b]. */
    fun toBitmapRect(l: Float, t: Float, r: Float, b: Float, vw: Int, vh: Int, bw: Int, bh: Int): IntArray {
        val sx = bw / vw.toFloat(); val sy = bh / vh.toFloat()
        val il = (l * sx).toInt().coerceIn(0, bw - 1)
        val it = (t * sy).toInt().coerceIn(0, bh - 1)
        val ir = (r * sx).toInt().coerceIn(il + 1, bw)
        val ib = (b * sy).toInt().coerceIn(it + 1, bh)
        return intArrayOf(il, it, ir, ib)
    }
}
