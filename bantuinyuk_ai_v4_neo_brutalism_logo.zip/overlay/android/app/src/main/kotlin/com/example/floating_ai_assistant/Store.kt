package com.example.floating_ai_assistant

import android.content.Context
import android.content.SharedPreferences

/** Prefs sisi native: posisi/gaya bubble. Backend, sesi, dan riwayat milik otak Dart (lib/brain). */
object Store {
    const val PREFS = "bubble_prefs"
    fun p(c: Context): SharedPreferences = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
}
