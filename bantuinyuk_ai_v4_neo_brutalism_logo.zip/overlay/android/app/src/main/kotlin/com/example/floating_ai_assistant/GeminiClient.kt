package com.example.floating_ai_assistant

import android.content.Context
import android.graphics.Bitmap
import android.os.Handler
import android.os.Looper
import java.io.ByteArrayOutputStream
import java.util.concurrent.Executors
import kotlin.math.max

class GeminiError(msg: String) : Exception(msg)

/**
 * Tipis: hanya mengecilkan bitmap jadi JPEG lalu menyerahkan ke otak Dart (lib/brain/gemini.dart),
 * yang mengurus login anonim, kuota, dan panggilan Edge Function `gemini-proxy`.
 */
object GeminiClient {
    private val io = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    class Call(val id: Int) {
        @Volatile var cancelled = false
        @Volatile var done = false
        fun cancel() { cancelled = true; if (!done) Brain.cancel(id) }
    }

    fun ask(ctx: Context, mode: String, text: String, bmp: Bitmap?, onDone: (Result<String>) -> Unit): Call {
        val call = Call(Brain.nextId())
        val app = ctx.applicationContext
        io.execute {
            val bytes: ByteArray? = try { bmp?.let { encode(it) } } catch (e: Exception) {
                main.post { call.done = true; if (!call.cancelled) onDone(Result.failure(GeminiError("Gagal memproses gambar."))) }
                return@execute
            }
            main.post {
                if (call.cancelled) { call.done = true; return@post }
                val args = HashMap<String, Any?>()
                args["id"] = call.id; args["mode"] = mode; args["text"] = text; args["image"] = bytes
                Brain.call(app, "ask", args, { call.cancelled }) { r ->
                    call.done = true
                    if (!call.cancelled) onDone(
                        r.fold(
                            { Result.success((it as? String).orEmpty()) },
                            { Result.failure<String>(GeminiError(it.message ?: "Gagal")) }
                        )
                    )
                }
            }
        }
        return call
    }

    private fun encode(b: Bitmap): ByteArray {
        val m = max(b.width, b.height)
        val sc = if (m > 1280) 1280f / m else 1f
        val s = if (sc < 1f) Bitmap.createScaledBitmap(b, (b.width * sc).toInt(), (b.height * sc).toInt(), true) else b
        val bo = ByteArrayOutputStream()
        s.compress(Bitmap.CompressFormat.JPEG, 80, bo)
        if (s !== b) s.recycle()
        return bo.toByteArray()
    }
}
