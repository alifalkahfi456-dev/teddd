package com.example.floating_ai_assistant

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Build
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Layanan aksesibilitas untuk aksi yang diminta pengguna secara eksplisit.
 * Tidak mengumpulkan teks layar ke server; hanya mengirim gesture tap lokal.
 */
class AutoAnswerAccessibilityService : AccessibilityService() {
    companion object {
        @Volatile private var instance: AutoAnswerAccessibilityService? = null
        val connected: Boolean get() = instance != null

        fun tap(x: Float, y: Float, done: ((Boolean) -> Unit)? = null): Boolean {
            val svc = instance ?: return false
            if (Build.VERSION.SDK_INT < 24) return false
            val path = Path().apply { moveTo(x, y) }
            val gesture = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0, 90))
                .build()
            return svc.dispatchGesture(gesture, object : GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) { done?.invoke(true) }
                override fun onCancelled(gestureDescription: GestureDescription?) { done?.invoke(false) }
            }, null)
        }
    }

    override fun onServiceConnected() { super.onServiceConnected(); instance = this }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit
    override fun onInterrupt() = Unit
    override fun onDestroy() { if (instance === this) instance = null; super.onDestroy() }
}
