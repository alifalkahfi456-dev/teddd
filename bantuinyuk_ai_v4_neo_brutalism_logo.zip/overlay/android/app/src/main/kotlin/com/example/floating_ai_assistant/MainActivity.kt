package com.example.floating_ai_assistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel

/**
 * Engine UI (Dart `main`). Urusan jendela/izin/layanan ditangani di sini; semua yang menyangkut
 * backend, sesi, sinkronisasi, dan riwayat diteruskan ke otak Dart lewat [Brain] supaya state-nya satu.
 */
class MainActivity : FlutterActivity() {
    private val prefs by lazy { Store.p(this) }
    private fun svc() = Intent(this, FloatingOverlayService::class.java)

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        Brain.warm(this)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "floating_assistant").setMethodCallHandler { call, res ->
            when (call.method) {
                "hasOverlayPermission" -> res.success(Settings.canDrawOverlays(this))
                "requestOverlayPermission" -> {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                    res.success(null)
                }
                "isRunning" -> res.success(FloatingOverlayService.running)
                "getConfig" -> {
                    val m = HashMap<String, Any?>()
                    m["size"] = prefs.getInt("size", 64)
                    m["alpha"] = prefs.getFloat("alpha", 0.85f).toDouble()
                    m["color"] = prefs.getInt("color", 0xFF3B82F6.toInt()).toLong() and 0xFFFFFFFFL
                    m["shape"] = prefs.getInt("shape", 0)
                    m["stealth"] = prefs.getBoolean("stealth", false)
                    // sbUrl, sbKey, historyOn, accepted: milik otak Dart. Bila otak gagal, UI tetap dapat gaya bubble.
                    Brain.call(this, "getSettings", null) { r ->
                        (r.getOrNull() as? Map<*, *>)?.forEach { (k, v) -> if (k is String) m[k] = v }
                        res.success(m)
                    }
                }
                "startBubble" -> {
                    if (!Settings.canDrawOverlays(this)) return@setMethodCallHandler res.error("NO_PERMISSION", "Izin overlay belum diberikan", null)
                    save(call)
                    if (Build.VERSION.SDK_INT >= 33 &&
                        checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                    ) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
                    startForegroundService(svc())
                    res.success(null)
                }
                "updateConfig" -> {
                    save(call)
                    if (FloatingOverlayService.running) startService(svc())
                    res.success(null)
                }
                "stopBubble" -> { stopService(svc()); res.success(null) }
                "killSwitch" -> {
                    if (FloatingOverlayService.running) startService(svc().setAction(FloatingOverlayService.ACTION_KILL))
                    res.success(null)
                }
                "openTool" -> {
                    if (!Settings.canDrawOverlays(this)) return@setMethodCallHandler res.error("NO_PERMISSION", "Izin overlay belum diberikan", null)
                    val i = svc().putExtra("tool", call.argument<String>("tool"))
                    if (FloatingOverlayService.running) startService(i) else startForegroundService(i)
                    res.success(null)
                }
                // Diteruskan apa adanya ke otak Dart.
                "saveBackend", "setHistoryOn", "setAccepted", "syncNow", "getHistory", "setFav", "clearHistory" -> relay(call, res)
                else -> res.notImplemented()
            }
        }
    }

    private fun relay(call: MethodCall, res: MethodChannel.Result) {
        Brain.call(this, call.method, call.arguments) { r ->
            r.onSuccess { res.success(it) }.onFailure { res.error("BRAIN", it.message, null) }
        }
    }

    private fun save(call: MethodCall) {
        val size = call.argument<Number>("size")?.toInt() ?: 64
        val alpha = call.argument<Number>("alpha")?.toFloat() ?: 0.85f
        val color = call.argument<Number>("color")?.toInt() ?: 0xFF3B82F6.toInt()
        val shape = call.argument<Number>("shape")?.toInt() ?: 0
        val stealth = call.argument<Boolean>("stealth") ?: prefs.getBoolean("stealth", false)
        val changed = size != prefs.getInt("size", 64) || alpha != prefs.getFloat("alpha", 0.85f) ||
            color != prefs.getInt("color", 0xFF3B82F6.toInt()) || shape != prefs.getInt("shape", 0) ||
            stealth != prefs.getBoolean("stealth", false)
        val e = prefs.edit().putInt("size", size).putFloat("alpha", alpha).putInt("color", color).putInt("shape", shape).putBoolean("stealth", stealth)
        if (changed) e.putLong("settings_ts", System.currentTimeMillis())
        e.apply()
    }
}
