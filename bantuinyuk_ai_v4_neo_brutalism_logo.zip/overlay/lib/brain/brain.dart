import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/services.dart';

import 'gemini.dart';
import 'parser.dart';
import 'store.dart';
import 'supabase.dart';
import 'sync.dart';

/// "Otak" aplikasi. Berjalan di FlutterEngine headless yang dipegang service overlay (jadi tetap hidup
/// walau Activity ditutup). Kotlin hanya memegang jendela overlay + capture + OCR, dan memanggil
/// otak lewat channel `floating_brain`. Semua login, sinkronisasi, Gemini, riwayat, dan parser ada di sini.
class Brain implements BubbleHost {
  static const _ch = MethodChannel('floating_brain');

  late final Store store;
  late final SupabaseApi api;
  late final GeminiClient gemini;
  late final Sync sync;

  final Map<int, HttpClientRequest> _calls = {};
  final Set<int> _cancelled = {};

  Future<void> start() async {
    store = await Store.open();
    api = SupabaseApi(store, IoTransport());
    gemini = GeminiClient(api);
    sync = Sync(store, api, this);
    _ch.setMethodCallHandler(_handle);
    await _ch.invokeMethod<void>('ready'); // Kotlin menahan panggilan sampai otak siap
  }

  // ---- BubbleHost: pengaturan bubble tinggal di Kotlin
  @override
  Future<Map<String, dynamic>> getBubble() async =>
      (await _ch.invokeMapMethod<String, dynamic>('getBubble')) ?? <String, dynamic>{};

  @override
  Future<void> setBubble(Map<String, dynamic> s) => _ch.invokeMethod<void>('setBubble', s);

  // ---- panggilan dari Kotlin
  Future<Object?> _handle(MethodCall c) async {
    final a = c.arguments is Map ? Map<String, dynamic>.from(c.arguments as Map) : <String, dynamic>{};
    try {
      switch (c.method) {
        case 'getSettings':
          return <String, Object?>{
            'sbUrl': store.backendUrl,
            'sbKey': store.anonKey,
            'historyOn': store.historyOn,
            'accepted': store.accepted,
          };
        case 'saveBackend':
          final url = ((a['url'] as String?) ?? '').trim().replaceAll(RegExp(r'/+$'), '');
          final key = ((a['key'] as String?) ?? '').trim();
          // Backend berganti → sesi lama tidak berlaku di project baru.
          if (url != store.backendUrl || key != store.anonKey) await api.resetSession();
          await store.setBackend(url, key);
          return null;
        case 'setHistoryOn':
          await store.setHistoryOn(a['on'] == true);
          return null;
        case 'setAccepted':
          await store.setAccepted();
          return null;
        case 'prepare':
          final text = (a['text'] as String?) ?? '';
          final parsed = QuestionParser.parse(text);
          return <String, Object?>{
            'readable': QuestionParser.isReadable(text),
            'prompt': QuestionParser.toPrompt(parsed, text),
            'needsImage': QuestionParser.needsImage(text, parsed),
          };
        case 'ask':
          return await _ask(a);
        case 'cancel':
          final id = (a['id'] as num?)?.toInt() ?? 0;
          final req = _calls[id];
          if (req != null) {
            req.abort();
          } else {
            _cancelled.add(id);
          }
          return null;
        case 'syncNow':
          try {
            return await sync.syncNow();
          } on Failure catch (e) {
            throw PlatformException(code: 'SYNC', message: e.message);
          } on SocketException {
            throw PlatformException(code: 'SYNC', message: 'Tidak ada koneksi internet.');
          } on TimeoutException {
            throw PlatformException(code: 'SYNC', message: 'Timeout. Coba lagi.');
          } catch (e) {
            throw PlatformException(code: 'SYNC', message: 'Sinkronisasi gagal: $e');
          }
        case 'getHistory':
          return jsonEncode(store.history());
        case 'setFav':
          await store.setFav((a['ts'] as num?)?.toInt() ?? 0, a['fav'] == true);
          sync.pushHistoryAsync();
          return null;
        case 'clearHistory':
          await store.clearHistory();
          sync.clearRemoteAsync();
          return null;
        default:
          throw MissingPluginException('Tidak dikenal: ${c.method}');
      }
    } on PlatformException {
      rethrow;
    } on MissingPluginException {
      rethrow;
    } on GeminiError catch (e) {
      throw PlatformException(code: 'ASK', message: e.message);
    } on Failure catch (e) {
      throw PlatformException(code: 'ERR', message: e.message);
    } catch (e) {
      throw PlatformException(code: 'ERR', message: 'Gagal: $e');
    }
  }

  Future<String> _ask(Map<String, dynamic> a) async {
    final id = (a['id'] as num?)?.toInt() ?? 0;
    final mode = (a['mode'] as String?) ?? 'ask';
    final text = (a['text'] as String?) ?? '';
    final img = a['image'] as Uint8List?;
    try {
      final ans = await gemini.ask(mode, text, img, onRequest: (req) {
        _calls[id] = req;
        if (_cancelled.contains(id)) req.abort();
      });
      if (mode == 'solve' && !ans.contains('TIDAK_TERBACA') && store.historyOn) {
        await store.addHistory(text.length > 300 ? text.substring(0, 300) : text, ans);
        sync.pushHistoryAsync();
      }
      return ans;
    } finally {
      _calls.remove(id);
      _cancelled.remove(id);
    }
  }
}
