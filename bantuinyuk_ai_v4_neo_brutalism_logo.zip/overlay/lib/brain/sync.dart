import 'dart:async';
import 'dart:convert';

import 'store.dart';
import 'supabase.dart';

/// Akses ke pengaturan bubble yang tinggal di sisi Kotlin (jendela overlay membacanya sinkron).
abstract class BubbleHost {
  Future<Map<String, dynamic>> getBubble();
  Future<void> setBubble(Map<String, dynamic> s);
}

int _int(Object? v, [int d = 0]) {
  if (v is num) return v.toInt();
  if (v is String) return int.tryParse(v) ?? d;
  return d;
}

double _dbl(Object? v, double d) => v is num ? v.toDouble() : d;

/// Sinkronisasi riwayat + pengaturan bubble ke Supabase (RLS: hanya data milik user).
class Sync {
  Sync(this.store, this.api, this.bubble);
  final Store store;
  final SupabaseApi api;
  final BubbleHost bubble;

  static final int defaultColor = 0xFF3B82F6 - 0x100000000; // ARGB bertanda, sama dengan Kotlin Int

  String _iso(int ms) => DateTime.fromMillisecondsSinceEpoch(ms, isUtc: true)
      .toIso8601String()
      .replaceFirst(RegExp(r'\.\d+Z$'), 'Z');

  List<Map<String, dynamic>> _historyRows() {
    final uid = api.uid;
    return store.history().map((o) {
      final ts = Store.tsOf(o);
      return <String, dynamic>{
        'user_id': uid,
        'client_ts': ts,
        'question': o['q'] ?? '',
        'answer': o['a'] ?? '',
        'favorite': o['fav'] == true,
        'created_at': _iso(ts),
      };
    }).toList();
  }

  Future<void> pushHistory() async {
    final rows = _historyRows();
    if (rows.isEmpty) return;
    final r = await api.call('POST', '/rest/v1/qa_history?on_conflict=user_id,client_ts', jsonEncode(rows),
        extra: {'Prefer': 'resolution=merge-duplicates,return=minimal'});
    if (!r.ok) throw Failure('Gagal kirim riwayat (${r.code}).', r.code);
  }

  Future<void> _deleteRemoteHistory() async {
    final r = await api.call('DELETE', '/rest/v1/qa_history?user_id=eq.${api.uid}', null);
    if (!r.ok) throw Failure('Gagal menghapus riwayat di server (${r.code}).', r.code);
    await store.setPendingClear(false);
  }

  /// Dipanggil setelah riwayat berubah. Diam-diam; sync manual memperbaiki bila gagal.
  void pushHistoryAsync() {
    if (!store.historyOn || !api.hasSession) return;
    unawaited(pushHistory().catchError((Object _) {}));
  }

  /// Hapus lokal sudah terjadi; hapus juga di server (ditandai pending bila gagal).
  void clearRemoteAsync() {
    if (!api.hasSession) return;
    unawaited(() async {
      try {
        await store.setPendingClear(true);
        await _deleteRemoteHistory();
      } catch (_) {}
    }());
  }

  /// Mengembalikan ringkasan untuk ditampilkan ke pengguna.
  Future<String> syncNow() async {
    await api.accessToken();
    final notes = <String>[];

    if (store.pendingClear) await _deleteRemoteHistory();

    // Pengaturan bubble: yang lebih baru (ts) menang.
    final sr = await api.call('GET', '/rest/v1/user_settings?select=settings&limit=1', null);
    if (!sr.ok) throw Failure('Gagal membaca pengaturan (${sr.code}).', sr.code);
    Map<String, dynamic>? remote;
    final decoded = jsonDecode(sr.body);
    if (decoded is List && decoded.isNotEmpty && decoded.first is Map) {
      final s = (decoded.first as Map)['settings'];
      if (s is Map) remote = Map<String, dynamic>.from(s);
    }
    final local = await bubble.getBubble();
    final localTs = _int(local['ts']);
    if (remote != null && _int(remote['ts']) > localTs) {
      await bubble.setBubble({
        'size': _int(remote['size'], 64),
        'alpha': _dbl(remote['alpha'], 0.85),
        'color': _int(remote['color'], defaultColor),
        'shape': _int(remote['shape']),
        'ts': _int(remote['ts']),
      });
      notes.add('Pengaturan bubble diambil dari server.');
    } else {
      final s = <String, dynamic>{
        'size': _int(local['size'], 64),
        'alpha': _dbl(local['alpha'], 0.85),
        'color': _int(local['color'], defaultColor),
        'shape': _int(local['shape']),
        'ts': localTs,
      };
      final body = {
        'user_id': api.uid,
        'settings': s,
        'updated_at': _iso(DateTime.now().millisecondsSinceEpoch),
      };
      final w = await api.call('POST', '/rest/v1/user_settings?on_conflict=user_id', jsonEncode(body),
          extra: {'Prefer': 'resolution=merge-duplicates,return=minimal'});
      if (!w.ok) throw Failure('Gagal kirim pengaturan (${w.code}).', w.code);
      notes.add('Pengaturan bubble dikirim ke server.');
    }

    // Riwayat: hanya bila pengguna mengaktifkannya.
    if (store.historyOn) {
      final hr = await api.call(
          'GET', '/rest/v1/qa_history?select=client_ts,question,answer,favorite&client_ts=not.is.null&order=client_ts.desc&limit=50', null);
      if (!hr.ok) throw Failure('Gagal membaca riwayat (${hr.code}).', hr.code);
      final arr = jsonDecode(hr.body);
      final items = <Map<String, dynamic>>[];
      if (arr is List) {
        for (final e in arr.whereType<Map>()) {
          items.add({'ts': _int(e['client_ts']), 'q': '${e['question'] ?? ''}', 'a': '${e['answer'] ?? ''}', 'fav': e['favorite'] == true});
        }
      }
      final added = await store.mergeHistory(items);
      await pushHistory();
      notes.add('Riwayat: $added item baru dari server.');
    } else {
      notes.add('Riwayat tidak disinkronkan (dimatikan).');
    }

    return notes.join(' ');
  }
}
