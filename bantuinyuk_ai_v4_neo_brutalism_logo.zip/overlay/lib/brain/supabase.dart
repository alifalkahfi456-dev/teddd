import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'store.dart';

class Failure implements Exception {
  Failure(this.message, [this.code = 0]);
  final String message;
  final int code;
  @override
  String toString() => message;
}

class Resp {
  const Resp(this.code, this.body);
  final int code;
  final String body;
  bool get ok => code >= 200 && code < 300;
}

typedef RequestHook = void Function(HttpClientRequest req);

/// Lapisan HTTP tipis supaya logika bisa dites dengan transport palsu.
abstract class Transport {
  Future<Resp> send(String method, String url, Map<String, String> headers, String? body, {RequestHook? onRequest});
}

class IoTransport implements Transport {
  @override
  Future<Resp> send(String method, String url, Map<String, String> headers, String? body, {RequestHook? onRequest}) async {
    final client = HttpClient()..connectionTimeout = const Duration(seconds: 10);
    HttpClientRequest? pending;
    try {
      final HttpClientRequest r = await client.openUrl(method, Uri.parse(url));
      pending = r;
      onRequest?.call(r);
      headers.forEach((k, v) => r.headers.set(k, v));
      if (body != null) {
        final bytes = utf8.encode(body);
        r.contentLength = bytes.length;
        r.add(bytes);
      }
      final res = await r.close().timeout(const Duration(seconds: 45));
      final text = await res.transform(utf8.decoder).join().timeout(const Duration(seconds: 45));
      return Resp(res.statusCode, text);
    } on TimeoutException {
      pending?.abort();
      rethrow;
    } finally {
      client.close(force: true);
    }
  }
}

/// Sesi Supabase Anonymous Sign-In. Aplikasi hanya memegang anon key (publik) + JWT milik user;
/// tidak ada service role / API key Gemini.
class SupabaseApi {
  SupabaseApi(this.store, this.transport);
  final Store store;
  final Transport transport;
  Future<String>? _inflight;

  bool get hasSession => store.refreshToken.isNotEmpty;
  String get uid => store.uid;

  Future<void> resetSession() => store.clearSession();

  String _base() {
    final b = store.backendUrl;
    if (b.isEmpty || store.anonKey.isEmpty) {
      throw Failure('Backend belum diatur. Isi URL & anon key Supabase di aplikasi (ikon pengaturan).');
    }
    return b;
  }

  Map<String, String> _authHeaders() => {'apikey': store.anonKey, 'Content-Type': 'application/json'};

  Failure _authError(Resp r) {
    var code = '';
    var msg = '';
    try {
      final j = jsonDecode(r.body);
      if (j is Map) {
        code = '${j['error_code'] ?? ''}';
        msg = '${j['msg'] ?? ''}';
        if (msg.isEmpty) msg = '${j['error_description'] ?? ''}';
      }
    } catch (_) {}
    if (code == 'anonymous_provider_disabled') {
      return Failure(
          'Anonymous sign-in belum aktif di Supabase (Authentication → Sign In / Providers → Allow anonymous sign-ins).', r.code);
    }
    return Failure('Login anonim gagal (${r.code}). $msg'.trim(), r.code);
  }

  Map<String, dynamic> _obj(String body) {
    try {
      final j = jsonDecode(body);
      if (j is Map) return Map<String, dynamic>.from(j);
    } catch (_) {}
    throw Failure('Respons login Supabase tidak lengkap.');
  }

  int _nowSec() => DateTime.now().millisecondsSinceEpoch ~/ 1000;

  Future<void> _store(Map<String, dynamic> j) async {
    final access = '${j['access_token'] ?? ''}';
    final refresh = '${j['refresh_token'] ?? ''}';
    if (access.isEmpty || refresh.isEmpty) throw Failure('Respons login Supabase tidak lengkap.');
    final ei = j['expires_in'];
    final exp = _nowSec() + (ei is num ? ei.toInt() : 3600);
    String? uid;
    final user = j['user'];
    if (user is Map && user['id'] is String && (user['id'] as String).isNotEmpty) uid = user['id'] as String;
    await store.saveSession(access: access, refresh: refresh, exp: exp, uid: uid);
  }

  /// Token valid; refresh / sign-in anonim bila perlu. Permintaan paralel berbagi satu proses
  /// (refresh token Supabase berotasi, dua refresh bersamaan bisa saling membatalkan).
  Future<String> accessToken({bool force = false}) {
    final running = _inflight;
    if (running != null) return running;
    final f = _accessToken(force).whenComplete(() => _inflight = null);
    _inflight = f;
    return f;
  }

  Future<String> _accessToken(bool force) async {
    final cur = store.accessToken;
    if (!force && cur.isNotEmpty && store.expiresAt - 60 > _nowSec()) return cur;
    final b = _base();
    final refresh = store.refreshToken;
    if (refresh.isNotEmpty) {
      final r = await transport.send(
          'POST', '$b/auth/v1/token?grant_type=refresh_token', _authHeaders(), jsonEncode({'refresh_token': refresh}));
      if (r.ok) {
        await _store(_obj(r.body));
        return store.accessToken;
      }
      if (r.code < 400 || r.code > 499) throw Failure('Server auth error (${r.code}).', r.code);
      await store.clearSession(); // refresh token ditolak → buat sesi anonim baru
    }
    final r = await transport.send('POST', '$b/auth/v1/signup', _authHeaders(), '{}');
    if (!r.ok) throw _authError(r);
    await _store(_obj(r.body));
    return store.accessToken;
  }

  /// Request REST/Functions dengan JWT user. Satu kali retry bila token ditolak (401).
  Future<Resp> call(String method, String path, String? body,
      {Map<String, String> extra = const {}, RequestHook? onRequest}) async {
    Resp? r;
    for (var attempt = 0; attempt < 2; attempt++) {
      final token = await accessToken(force: attempt == 1);
      final h = <String, String>{
        'apikey': store.anonKey,
        'Authorization': 'Bearer $token',
        'Content-Type': 'application/json',
        ...extra,
      };
      r = await transport.send(method, _base() + path, h, body, onRequest: onRequest);
      if (r.code != 401) return r;
    }
    return r!;
  }
}
