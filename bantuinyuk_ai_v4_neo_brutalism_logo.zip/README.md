# bantuinYuk AI — Floating Assistant v4

## Jalankan
1. `bash setup.sh` (Flutter 3.32.8 + JDK 17 + Android SDK). Skrip membuat project Android, menimpa dengan `overlay/`,
   menambah ML Kit + androidx.core + JUnit ke gradle, lalu analyze / unit test / build APK debug.
2. Backend Supabase:
   - Dashboard → **Authentication → Sign In / Providers → aktifkan "Allow anonymous sign-ins"** (wajib; kuota & sinkronisasi memakainya).
   - `supabase db push` (menjalankan `0001_init.sql` dan `0002_auth_quota_sync.sql`).
   - `supabase secrets set GEMINI_API_KEY=... GEMINI_MODEL=... DAILY_LIMIT=100`
   - `supabase functions deploy gemini-proxy --no-verify-jwt` (JWT user diverifikasi di dalam fungsi lewat `auth.getUser`).
   - Cek nama model aktif (ListModels) sebelum rilis; default `gemini-flash-latest`.
3. Di aplikasi: ikon pengaturan → isi Supabase URL + anon key → Simpan.

## Auth, kuota, sinkronisasi (baru di v3)
- Klien membuat sesi **anonim** Supabase saat pertama kali butuh (panggilan Gemini pertama atau tombol Sinkronkan), menyimpan
  access/refresh token, dan me-refresh otomatis. Anon key saja tidak cukup memanggil `gemini-proxy` (ditolak 401).
- Kuota dihitung **per user_id dari JWT** (bukan header yang bisa dipalsukan), atomik lewat fungsi SQL `consume_quota`
  (advisory lock per user; request paralel tidak bisa melewati batas). Bila Gemini gagal/timeout/kosong, kuota dikembalikan.
- Pengaturan > **Sinkronkan sekarang**: pengaturan bubble (yang `ts`-nya lebih baru menang) dan, jika riwayat diaktifkan,
  riwayat (item server yang belum ada di lokal ditambahkan; lokal tidak ditimpa). Riwayat baru, favorit, dan hapus riwayat
  juga dikirim otomatis bila sesi sudah ada. Hapus riwayat yang gagal di server ditandai pending dan diulang saat sinkron.
- Tidak ada UI login email. Akun anonim hilang bila data aplikasi dihapus/di-install ulang (riwayat server milik akun lama
  tidak terbawa). Menautkan email ke akun anonim (`updateUser`) adalah langkah terpisah yang belum dibuat.

## Arsitektur v4: logika di Dart, Kotlin hanya jendela + capture
```
Kotlin (native)                         Dart
  FloatingOverlayService, Ui, Tools        lib/main.dart ............ UI dashboard (engine Activity)
  OverlayWindowManager                     lib/brain/ ............... "otak" (engine headless)
  ScreenCaptureManager + ML Kit OCR          parser.dart   deteksi soal
  CropMath, Store (prefs bubble)             supabase.dart login anonim, token, HTTP
  Brain.kt  <── channel floating_brain ──>   gemini.dart   panggilan gemini-proxy
  GeminiClient (bitmap → JPEG)               sync.dart     sinkronisasi pengaturan + riwayat
                                             store.dart    backend, sesi, riwayat (shared_preferences)
```
- **Satu pemilik state.** Otak berjalan di `FlutterEngine` headless yang dibuat `Brain.kt` dan dipegang selama proses hidup,
  jadi overlay tetap bisa bertanya ke Gemini walau Activity ditutup. UI Flutter tidak menyentuh storage: panggilannya
  (`saveBackend`, `syncNow`, `getHistory`, …) diteruskan `MainActivity` → `Brain` → otak. Dua isolate tidak pernah
  memegang salinan state/token yang berselisih (refresh token Supabase berotasi, jadi ini penting).
- **Yang tetap di Kotlin** karena memang urusan Android: jendela overlay, MediaProjection, ML Kit OCR, pemotongan/pengecilan
  bitmap, dan prefs gaya/posisi bubble (dibaca sinkron saat menggambar jendela). Otak membaca/menulis gaya bubble lewat
  `getBubble`/`setBubble` untuk sinkronisasi.
- **Protokol** Kotlin → Dart: `ask`, `cancel`, `prepare`, `getSettings`, `saveBackend`, `setHistoryOn`, `setAccepted`,
  `syncNow`, `getHistory`, `setFav`, `clearHistory`. Dart → Kotlin: `ready`, `getBubble`, `setBubble`.
  Kotlin menahan panggilan sampai otak mengirim `ready` (maks 15 dtk, lalu gagal dengan pesan jelas).
- Riwayat dicatat otak sendiri saat `ask` mode `solve` berhasil; Kotlin tidak lagi menyentuh riwayat.

## Migrasi dari v3
- Data v3 (URL/anon key backend, sesi anonim, riwayat lokal) ada di SharedPreferences native dan **tidak dibaca**
  otak Dart (plugin `shared_preferences` memakai file lain). Setelah update: isi ulang URL + anon key di Pengaturan;
  sesi anonim baru dibuat otomatis, jadi riwayat lama (lokal maupun di akun anonim lama) tidak ikut terbawa.
- Ukuran/warna/bentuk/posisi bubble tetap di prefs native, jadi tidak berubah.

## Peta tahap
| Tahap | Lokasi |
|---|---|
| 1–2 Bubble + panel | `FloatingOverlayService.kt`, `Ui.kt` (BubbleView) |
| 3 Dashboard, pengaturan bubble, menu alat | `lib/main.dart`, `Tools.openSettings`, `showToolsMenu` (tahan bubble 0,45 dtk) |
| 4 Capture + crop (✕/↺/✓, Smart Crop) | `ScreenCaptureManager.kt`, `CropView` |
| 5 OCR + deteksi soal | OCR: ML Kit on-device (Kotlin). Deteksi soal: `lib/brain/parser.dart` |
| 6 Gemini via Edge Function | `lib/brain/gemini.dart`, `lib/brain/supabase.dart`, `supabase/functions/gemini-proxy` |
| 7 Jawaban + penjelasan di panel | panel mode diperluas |
| 8 Jendela alat (Pencarian, Tanya Gemini, Terjemahan, Galeri, Gambar) | `Tools.kt`, `OverlayWindowManager.kt` (maks 3 jendela) |
| 9 Riwayat, favorit, TTS, Kill Switch, sinkronisasi | `lib/brain/store.dart`, `lib/brain/sync.dart`, panel, notifikasi |

## Perbaikan bug di v3
- Capture: callback `onStop` proyeksi lama bisa mematikan sesi baru → kini hanya bereaksi bila proyeksi itu masih aktif.
- Kill Switch kini juga melepas tipe foreground `mediaProjection` dan memperbarui teks notifikasi.
- Deteksi "layar diblokir (FLAG_SECURE)" memindai area tengah layar, bukan grid 8×8 yang salah mendeteksi tema gelap AMOLED.
- Bitmap perantara capture di-recycle; `TrampolineActivity` tidak membuka ulang dialog saat dibuat ulang (rotasi).
- Dashboard Flutter membaca ulang konfigurasi saat dibuka kembali (sebelumnya slider bisa menimpa warna/bentuk yang baru diubah
  dari jendela Pengaturan Bubble di overlay).
- `setup.sh`: hapus `test/widget_test.dart` bawaan template (merujuk `MyApp`, membuat `flutter analyze` gagal), `--no-fatal-infos`,
  dan tambah `androidx.core` eksplisit (`ServiceCompat` butuh versi baru).

## Status verifikasi (jujur)
Sudah dijalankan untuk v4 (lingkungan ini hanya punya Java/Node/Python):
- Ekspektasi 6 tes parser diperiksa dengan port JS yang setara (semua cocok), keseimbangan kurung semua file Dart/Kotlin baru diperiksa,
  dan semua anggota `Store` yang dipakai kode Dart terdefinisi.
- Edge Function, migrasi SQL, dan semua klaim backend v3 tidak berubah (`supabase/` identik dengan v3).

**Belum dijalankan sama sekali untuk v4** (tidak ada Dart/Flutter/Kotlin compiler, Android SDK, perangkat, atau Supabase di sini):
- `flutter analyze`, `flutter test` (tes parser + `test/brain_test.dart` dengan transport palsu), `./gradlew testDebugUnitTest`, build APK.
- Kompilasi Kotlin v4 (v3 sempat dikompilasi dengan stub; perubahan v4 — `Brain.kt`, `GeminiClient.kt`, `MainActivity.kt`, 4 titik di
  `FloatingOverlayService.kt` — belum).
- Semua perilaku di perangkat: engine headless di service, handshake `ready`, aliran data UI → Kotlin → otak, pembatalan request,
  sign-in anonim/refresh/sinkronisasi terhadap Supabase asli.
Jalankan `bash setup.sh`; urutan analyze → test → build akan menunjukkan kesalahan pertama bila ada.

## Batasan
- Anonymous Sign-In bisa "diternakkan" (hapus data aplikasi → akun baru → kuota baru). Itu jauh lebih sulit daripada memalsukan
  header, dan Supabase membatasi sign-in anonim per IP (lihat Authentication → Rate Limits; bisa ditambah CAPTCHA), tetapi bukan
  perlindungan mutlak. Untuk batas biaya keras, set juga budget/kuota di sisi Google AI.
- Token sesi disimpan di SharedPreferences privat aplikasi lewat plugin `shared_preferences` (tidak dienkripsi tambahan;
  `flutter_secure_storage` bisa dipakai bila perlu).
- Engine headless menambah memori (kira-kira puluhan MB) dan panggilan pertama setelah proses dimulai ulang sedikit lebih lambat.
- Layar FLAG_SECURE hanya dideteksi (layar hitam) dan dilaporkan jujur; tidak diakali. Tidak ada fitur anti-proctoring.
- Android 14+ meminta persetujuan capture tiap sesi; sesi berakhir saat Stop capture/Kill Switch.
- Blur lintas-aplikasi hanya Android 12+ dan tergantung perangkat; ada fallback gradient.


## Auto jawab lintas aplikasi (fitur baru)
- Panel overlay menyediakan **Auto jawab** dan **Izin otomatisasi**. Pengguna harus mengaktifkan layanan Floating AI secara manual pada Pengaturan Android → Aksesibilitas; izin ini tidak diaktifkan diam-diam.
- Saat dimulai, aplikasi mengambil layar dengan izin MediaProjection yang sudah disetujui, membaca opsi lewat ML Kit, meminta jawaban Gemini melalui Edge Function yang ada, lalu mengetuk baris opsi berlabel A–E. Sesudahnya hanya mengetuk tombol lanjut yang teksnya terbaca (Lanjutkan/Berikutnya/Next/Continue/Submit dan variasinya), lalu mengulang.
- Auto jawab berhenti jika label opsi, tombol lanjut, atau hasil AI tidak cukup jelas. Gunakan tombol Auto jawab lagi untuk berhenti; **Stop capture (privasi)** juga menghentikan loop dan melepas capture.
- Kunci Gemini tetap berada di secret Supabase; tidak ada API key yang ditambahkan ke aplikasi Android. Otomatisasi gesture dilakukan lokal lewat `AutoAnswerAccessibilityService`.
- Batasan: ini tidak menjamin kompatibilitas dengan setiap aplikasi/website. Opsi harus terbaca OCR sebagai label A–E dan tombol lanjut harus memiliki teks yang terdeteksi. Tombol ikon tanpa teks, halaman yang memakai `FLAG_SECURE`, dialog sistem, atau UI khusus dapat memerlukan tindakan manual. Gesture API tersedia pada Android 7.0+.
- Pengujian build perangkat belum dijalankan di lingkungan ini karena Flutter/Android SDK tidak tersedia. Jalankan `bash setup.sh` di lingkungan Flutter 3.32.8 + JDK 17 untuk analyze, tes, dan build APK; uji dahulu pada kuis latihan yang tidak penting.

## Tampilan Neo-Brutalism dan mode bola transparan

- Tema aplikasi utama, panel overlay, menu alat, dan tombol menggunakan gaya neo-brutalism: latar terang, warna aksen tegas, outline hitam, sudut kotak, dan bayangan keras.
- Pengaturan **Sembunyikan bola** menurunkan opacity bola menjadi sekitar 3.5% tanpa menghapus area sentuh. Tekan lama pada posisi bola yang sama untuk membuka menu dan memilih **Tampilkan bola normal**. Pengaturan juga tersedia dari menu Pengaturan Bubble.
- Mode ini bukan penyamaran terhadap sistem keamanan atau pengawasan; bola hanya dibuat sangat transparan dan tetap bisa disentuh.
