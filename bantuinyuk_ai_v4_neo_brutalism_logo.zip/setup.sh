#!/usr/bin/env bash
# Jalankan dari folder ini: bash setup.sh   (butuh Flutter 3.32.8 + JDK 17 + Android SDK)
set -e
flutter create --org com.example --project-name floating_ai_assistant --platforms android app
cp -r overlay/. app/
rm -f app/test/widget_test.dart   # template bawaan merujuk MyApp yang sudah tidak ada
GR=app/android/app/build.gradle.kts
[ -f "$GR" ] || { echo "build.gradle.kts tidak ditemukan"; exit 1; }
cat >> "$GR" <<'G'

dependencies {
    implementation("androidx.core:core:1.13.1")   // ServiceCompat / NotificationCompat dipakai langsung
    implementation("com.google.mlkit:text-recognition:16.0.1")
    testImplementation("junit:junit:4.13.2")
}
G
cd app
flutter pub add shared_preferences                # penyimpanan "otak" Dart (lib/brain/store.dart)
flutter pub get
flutter analyze --no-fatal-infos
flutter test || echo "tes Dart gagal/dilewati"    # parser + logika auth/Gemini/sinkronisasi (transport palsu)
(cd android && ./gradlew :app:testDebugUnitTest) || echo "unit test Kotlin gagal/dilewati"
flutter build apk --debug
